package com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners


interface YouTubePlayerFullScreenListener {
    fun onYouTubePlayerEnterFullScreen()
    fun onYouTubePlayerExitFullScreen()
}
